﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage : MonoBehaviour
{
    /// <summary>回転スピード</summary>
    float m_RotateSpeed = -30.0f;
    /// <summary>回転量</summary>
    Vector3 m_StageRotate = new Vector3(0.0f, 0.0f, 0.0f);

    void Start()
    {
    }

    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            MouseRotate();
        }
    }

    void MouseRotate()
    {
        m_StageRotate.z = Input.GetAxis("Mouse X") * m_RotateSpeed * Time.deltaTime;

        transform.Rotate(m_StageRotate);
    }
}
