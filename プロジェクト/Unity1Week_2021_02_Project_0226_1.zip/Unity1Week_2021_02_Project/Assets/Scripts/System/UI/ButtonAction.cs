﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//-------------------------------------------------------------------------------
/// <summary>
/// ボタンで使用するアクション
/// </summary>
public class ButtonAction : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// シーン変移
	/// </summary>
	/// <param name="sceneName">次のシーン名</param>
	public void SceneChange(string sceneName)
	{
		SceneChangeManager.Instance.SceneChange(sceneName);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// インゲームへシーン変移
	/// </summary>
	/// <param name="stageNum_">ステージ番号</param>
	public void SceneChangeInGame(int stageNum_)
	{
		InGameManager.stageNum = stageNum_;
		SceneChangeManager.Instance.SceneChange("InGameScene");
	}
	//-------------------------------------------------------------------------------
}
