﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{
    void OnTriggerStay(Collider other)
    {
        // 当たっているオブジェクトの距離を計算
        float Distance = Vector2.Distance(other.transform.position, transform.position);

        if(Distance <= 0.1f)
        {
            if (other.gameObject.CompareTag("Ball"))
            {
                InGameManager.Instance.GameEnd();
            }
        }
    }
}
