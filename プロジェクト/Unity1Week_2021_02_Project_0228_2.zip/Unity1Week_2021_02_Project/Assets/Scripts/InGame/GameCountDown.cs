﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// ゲームスタートカウントダウン処理
/// </summary>
public class GameCountDown : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 使用するテキスト
    /// </summary>
    [SerializeField] Text countText = null;
    /// <summary>
    /// カウントダウン秒数
    /// </summary>
    [SerializeField] float countTime = 1;
    /// <summary>
    /// カウントダウンをするか
    /// </summary>
    bool isCount;
	//-------------------------------------------------------------------------------
	private void Awake()
	{
        Active(false);
	}
	//-------------------------------------------------------------------------------
	private void Update()
	{
        //有効の場合のみ、処理する
		if (!this.isCount) { return; }

        //カウントダウン
        this.countTime -= Time.deltaTime;

        //UI反映
        string msg = "";
        if(this.countTime >= 0.5f) { msg = this.countTime.ToString("F0"); }
        else { msg = "START"; }
        this.countText.text = msg;	
    }
	//-------------------------------------------------------------------------------
    /// <summary>
    /// 処理、描画の有効・無効化
    /// </summary>
    /// <param name="isActive">有効にするか</param>
    void Active(bool isActive)
	{
        this.isCount = isActive;
        this.countText.enabled = isActive;
	}
	//-------------------------------------------------------------------------------
    /// <summary>
    /// ゲームスタートのカウントダウン処理の開始
    /// </summary>
	public void CountDownStart()
	{
        StartCoroutine(CountDown());
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// ゲーム開始までのカウントダウン
    /// </summary>
    /// <returns></returns>
    IEnumerator CountDown()
    {
        //カウントダウン開始
        Active(true);

        //秒数が切れるまで待つ
        yield return new WaitUntil(() => this.countTime <= 0.0f);

        //カウントダウン終了
        Active(false);

        //ゲーム開始処理
        InGameManager.Instance.GameStart();

        yield break;
    }
    //-------------------------------------------------------------------------------
}
