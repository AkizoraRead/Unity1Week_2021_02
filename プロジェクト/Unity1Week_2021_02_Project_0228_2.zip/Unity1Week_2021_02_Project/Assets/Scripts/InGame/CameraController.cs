﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// カメラ操作
/// </summary>
public class CameraController : MonoBehaviour
{
    [SerializeField] Camera mainCamera = null;
    void Start()
    {
        this.mainCamera.orthographicSize = InGameManager.Instance.MapPosX.Length;
    }

}
