﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    /// <summary>プレイヤーの出現位置</summary>
    Transform m_PlayerPop;
    /// <summary>落下フラグ</summary>
    bool m_FallFrag;
    /// <summary>ライフ</summary>
    //public int m_Life = 3;

    /// <summary>アニメーター</summary>
    Animator m_Animator;
    /// <summary>リジットボディ</summary>
    Rigidbody m_Rigidbody;

    /// <summary>落下のアニメーションのハッシュ</summary>
    int s_FallHash = Animator.StringToHash("FallFrag");

    void Start()
    {
        // アニメーターの取得
        m_Animator = GetComponent<Animator>();
        // リジットボディの取得
        m_Rigidbody = GetComponent<Rigidbody>();
        // プレイヤーの出現位置を取得
        m_PlayerPop = GameObject.FindGameObjectWithTag("Player_Pop").transform;
        // ボールをプレイヤーの出現位置に設定
        transform.position = m_PlayerPop.position;
        // 状態を初期化
        m_FallFrag = false;
    }

    void Update()
    {
        // 落下した状態の場合
        if (m_FallFrag)
        {
            // 元の位置に戻る
            ReturnToTheOriginalPosition();
        }
    }

    void OnTriggerStay(Collider other)
    {
        // 当たっているオブジェクトの距離を計算
        float Distance = Vector2.Distance(other.transform.position, transform.position);

        // 距離が0.1以下だった場合
        if(Distance <= 0.1f)
        {
            // 当たっているオブジェクトのタグがholeだった場合
            if (other.gameObject.CompareTag("hole"))
            {
                //// 落下した状態の場合
                //// ライフが0より大きかった場合
                //if (m_FallFrag && m_Life > 0)
                //{
                //    // 出現位置に戻る
                //    ReturnToTheOriginalPosition();
                //    // ライフを減らす
                //    m_Life--;
                //    // これ以上の処理を行わない
                //    return;
                //}

                // 当たってるに近づく
                Vector3 Distance_Ve3 = other.transform.position - transform.position;
                transform.position += Distance_Ve3;

                // 重力を無効
                m_Rigidbody.useGravity = false;
                // 落下アニメーションを再生
                m_Animator.SetBool(s_FallHash, true);

            }
            // ゴール
            if (other.gameObject.CompareTag("Goal") && !m_FallFrag)
            {
                // リジットボディの無効
                m_Rigidbody.velocity = Vector3.zero;
                // 重力を無効
                m_Rigidbody.useGravity = false;
                // 回転を止める
                transform.eulerAngles = Vector3.zero;
            }
        }
    }

    /// <summary>出現位置に戻る</summary>
    void ReturnToTheOriginalPosition()
    {
        // 大きくなるアニメーションを再生
        m_Animator.SetBool(s_FallHash, false);
        // 重力を有効
        m_Rigidbody.useGravity = true;
        // ボールをプレイヤーの出現位置に設定
        transform.position = m_PlayerPop.position;
    }

    /// <summary>落下した状態を変える</summary>
    /// <param name="Frag"></param>
    public void isFallFragChange(int Frag)
    {
        if (Frag == 0) m_FallFrag = true;
        if (Frag == 1) m_FallFrag = false;
    }

    /// <summary>ライフ(プロパティ)</summary>
    //public int Life
    //{
    //    get { return this.m_Life; }
    //    private set { this.m_Life = value; }
    //}

    public bool FillFrag
    {
        get { return this.m_FallFrag; }
        private set { this.m_FallFrag = value; }
    }

    /// <summary>Holeに入った時のSE</summary>
    public void PlaySEHoleIn()
	{
        //SE
        SEController.Instance.Play("disappear", 0.3f);
    }
    /// <summary>出現のSE</summary>
    public void PlaySEAppear()
	{
        //SE
        SEController.Instance.Play("appear", 0.3f);
    }
}
