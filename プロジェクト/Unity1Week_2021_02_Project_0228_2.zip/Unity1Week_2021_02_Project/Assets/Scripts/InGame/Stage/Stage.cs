﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage : MonoBehaviour
{
    /// <summary>回転スピード</summary>
    float m_RotateSpeed = -10.0f;
    /// <summary>回転量</summary>
    Vector3 m_StageRotate = Vector3.zero;

    /// <summary>マウスの閾値</summary>
    const float m_mouse_threshold = 0.5f;
    /// <summary>回転量の閾値</summary>
    const float m_rotate_threshold = 0.2f;
    /// <summary>入力の閾値</summary>
    const float m_input_threshold = 0.7f;

    void Update()
    {
        // マウスの左クリックが押されている場合
        if (Input.GetMouseButton(0) && InGameManager.Instance.IsGaming)
        {
            // ステージの回転を行う
            MouseRotate();
        }

        // マウスの左クリックが押した時・押された時に回転量をリセットする
        if (Input.GetMouseButtonUp(0) || Input.GetMouseButtonDown(0))
        {
            m_StageRotate = Vector3.zero;
        }
    }

    /// <summary>ステージの回転</summary>
    void MouseRotate()
    {
        // マウスの入力値
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        // マウスが入力された場合
        if (mouseX > m_mouse_threshold || mouseX < -m_mouse_threshold) m_StageRotate += Vector3.forward * mouseX * m_RotateSpeed * Time.deltaTime;
        else if (mouseY > m_mouse_threshold || mouseY < -0.5f) m_StageRotate += Vector3.forward * mouseY * m_RotateSpeed * Time.deltaTime;

        // 回転量のZ軸が0.2以下から-0.2以上だった場合、回転量をリセットする。
        if (m_StageRotate.z <= m_rotate_threshold && m_StageRotate.z >= -m_rotate_threshold) m_StageRotate = Vector3.zero;

        // 入力制限
        if (m_StageRotate.z >= m_input_threshold) m_StageRotate.z = m_input_threshold;
        if (m_StageRotate.z <= -m_input_threshold) m_StageRotate.z = -m_input_threshold;

        // 回転
        if (m_StageRotate != Vector3.zero) transform.Rotate(m_StageRotate); 
    }
}
