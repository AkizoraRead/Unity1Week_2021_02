﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 経過時間計算
/// </summary>
public class Timer : SingletonClass<Timer>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 経過時間
	/// </summary>
	float deltaTime;
	/// <summary>
	/// 計測するか
	/// </summary>
	public bool isCount;
	//-------------------------------------------------------------------------------
	//プロパティ
	/// <summary>
	/// 経過時間
	/// </summary>
	public float DeltaTime
	{
		get { return this.deltaTime; }
		private set { this.deltaTime = value; }
	}
	//-------------------------------------------------------------------------------
	private void Update()
	{
		//有効でない場合、処理しない
		if (!this.isCount) { return; }

		DeltaTime += Time.deltaTime;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 時間計測開始
	/// </summary>
	public void TimeStart()
	{
		this.isCount = true;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 計測一時停止
	/// </summary>
	public void TimeStop()
	{
		this.isCount = false;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 時間リセット
	/// </summary>
	public void Reset()
	{
		DeltaTime = 0.0f;
	}
	//-------------------------------------------------------------------------------

}
