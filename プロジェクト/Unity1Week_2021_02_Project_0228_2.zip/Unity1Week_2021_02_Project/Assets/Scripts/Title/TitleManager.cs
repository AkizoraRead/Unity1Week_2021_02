﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// タイトル統括
/// </summary>
public class TitleManager : SingletonClass<TitleManager>
{
    //-------------------------------------------------------------------------------
    void Start()
    {
        //BGM再生
        BGMController.Instance.Play("TitleBGM");
    }
    //-------------------------------------------------------------------------------

}
