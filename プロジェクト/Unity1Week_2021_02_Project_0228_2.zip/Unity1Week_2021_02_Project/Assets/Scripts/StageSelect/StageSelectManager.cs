﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// ステージ選択統括
/// </summary>
public class StageSelectManager : SingletonClass<StageSelectManager>
{
    //-------------------------------------------------------------------------------
    void Start()
    {
        //BGM再生
        BGMController.Instance.Play("TitleBGM");
    }
    //-------------------------------------------------------------------------------
}
