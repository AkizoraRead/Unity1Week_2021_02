﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// エフェクト単体の操作
/// </summary>
public class EffectController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	//消滅処理
	public void Destroy()
	{
		Destroy(gameObject);
	}
	//-------------------------------------------------------------------------------

}
