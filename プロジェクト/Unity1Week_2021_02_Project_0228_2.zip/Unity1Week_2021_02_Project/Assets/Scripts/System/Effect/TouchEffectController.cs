﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
/// <summary>
/// タッチエフェクト生成操作
/// </summary>
public class TouchEffectController : SingletonClass<TouchEffectController>
{
    //--------------------------------------------------------------------------
    /// <summary>
    /// エフェクト生成先のCanvas
    /// </summary>
    [SerializeField] Canvas effectCanvas = null;
    //--------------------------------------------------------------------------
    protected override void AwakeInitialize()
    {
        DontDestroyOnLoad(gameObject);
    }
    //--------------------------------------------------------------------------
    void Update()
    {
        //タッチした場所にエフェクト生成
        if(TouchScreenController.Instance.CheckTouchBegan())
		{
            GameObject obj = EffectGenerator.Instance.EffectGenerate("TAP");
            obj.transform.position = TouchScreenController.Instance.touchStartPos;
            obj.transform.SetParent(this.effectCanvas.gameObject.transform);
        }
    }
    //--------------------------------------------------------------------------
}
