﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackEffectController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    /// <summary>
    /// エフェクト生成先のCanvas
    /// </summary>
    [SerializeField] Canvas effectCanvas = null;

    float delta;
    /// <summary>
    /// 生成間隔
    /// </summary>
    float intervalTime;
	//--------------------------------------------------------------------------
	private void Start()
	{
        this.intervalTime = 0.5f;
	}

	void Update()
    {
        this.delta += Time.deltaTime;

        if(this.intervalTime < this.delta) { EffectGenerate(); }
    }

    /// <summary>
    /// エフェクト生成
    /// </summary>
    public void EffectGenerate()
	{
        //エフェクト設定
        int effectNum = Random.Range(1,4);  // 1～3
        //エフェクト生成
        GameObject obj = EffectGenerator.Instance.EffectGenerate("RING" + effectNum.ToString());
        obj.transform.SetParent(this.effectCanvas.gameObject.transform);
        obj.transform.localPosition = new Vector2
            (
                Random.Range(-450.0f,450.0f),
                Random.Range(-250.0f,250.0f)
            );
        int scale = Random.Range(1,4);
        obj.transform.localScale = new Vector2
            (
                scale,
                scale
            );
        //生成間隔設定
        this.intervalTime = Random.Range(0.2f, 0.5f);
        this.delta = 0.0f;
	}
}
