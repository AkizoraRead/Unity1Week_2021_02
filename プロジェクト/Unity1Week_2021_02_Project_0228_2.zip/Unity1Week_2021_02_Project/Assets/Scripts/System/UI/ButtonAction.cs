﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//-------------------------------------------------------------------------------
/// <summary>
/// ボタンで使用するアクション
/// </summary>
public class ButtonAction : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// シーン変移
	/// </summary>
	/// <param name="sceneName">次のシーン名</param>
	public void SceneChange(string sceneName)
	{
		SceneChangeManager.Instance.SceneChange(sceneName);
		//SE
		PlaySE("system_enter");
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// シーン変移 InGame
	/// </summary>
	/// <param name="stageNum_">ステージ番号</param>
	public void SceneChangeInGame(int stageNum_)
	{
		//ステージ番号代入
		InGameManager.stageNum = stageNum_;
		//シーン変移
		SceneChangeManager.Instance.SceneChange("InGameScene");
		//SE
		PlaySE("system_enter");
	}
	//-------------------------------------------------------------------------------
	public void SceneChangeNextInGame()
	{
		//ステージ番号変更
		int num = InGameManager.stageNum + 1;
		//ステージ番号がマップ以上の場合、処理せず
		if(num > 5) { return; }
		else { InGameManager.stageNum = num; }

		//シーン変移
		SceneChangeManager.Instance.SceneChange("InGameScene");

		//SE
		PlaySE("system_enter");
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ステージ選択、決定の確認ウィンドウの表示
	/// </summary>
	/// <param name="stageNum_">ステージ番号</param>
	public void SelectStage(int stageNum_)
	{
		//SE
		PlaySE("system_select");
		//ウィンドウ表示
		ConfirmationObjController.Instance.Active
			(
				(() => SceneChangeInGame(stageNum_)),   //シーン変移
				(()=>PlaySE("system_select")),
				"ステージ" + stageNum_
			);

		
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// SE再生
	/// </summary>
	/// <param name="sName">音源名</param>
	public void PlaySE(string sName)
	{
		SEController.Instance.Play(sName, 0.3f);
	}
	//-------------------------------------------------------------------------------
}
