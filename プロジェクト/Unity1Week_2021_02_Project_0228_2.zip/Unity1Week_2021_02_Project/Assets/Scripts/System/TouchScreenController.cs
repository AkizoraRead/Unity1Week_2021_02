﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//-------------------------------------------------------------------------------
/// <summary>
/// 画面タッチ
/// </summary>
public class TouchScreenController : SingletonClass<TouchScreenController>
{
	/// <summary>
	/// 画面をタッチしているか
	/// </summary>
	public bool			isTouch;
	/// <summary>
	/// どんなタッチ状態か
	/// </summary>
	public TouchPhase	touchMode;
	/// <summary>
	/// タッチ位置(現在)
	/// </summary>
	public Vector2		touchNowPos;
	/// <summary>
	/// タッチ位置(始め)
	/// </summary>
	public Vector2		touchStartPos;

	//-------------------------------------------------------------------------------
	void Start()
	{
		this.isTouch = false;
	}

	void Update()
	{
		//入力に応じて変更
		if (Input.GetMouseButtonDown(0))
		{
			this.isTouch		= true;
			this.touchMode		= TouchPhase.Began;
			this.touchNowPos	= Input.mousePosition;
			this.touchStartPos	= Input.mousePosition;
			Debug.Log(this.touchMode);
		}
		else if (Input.GetMouseButtonUp(0))
		{
			this.isTouch		= true;
			this.touchMode		= TouchPhase.Ended;
			this.touchNowPos	= Input.mousePosition;
			Debug.Log(this.touchMode);
		}
		else if (Input.GetMouseButton(0))
		{
			this.isTouch		= true;
			this.touchMode		= TouchPhase.Moved;
			this.touchNowPos	= Input.mousePosition;

			Debug.Log(this.touchMode);
		}
		//入力ナシ
		else
		{
			this.isTouch = false;
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// タッチしている && 押した瞬間かを返す
	/// </summary>
	/// <returns>結果</returns>
	public bool CheckTouchBegan()
	{
		return this.isTouch && this.touchMode == TouchPhase.Began;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// タッチしている && 押している間かを返す
	/// </summary>
	/// <returns>結果</returns>
	public bool CheckTouchMoved()
	{
		return this.isTouch && this.touchMode == TouchPhase.Moved;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// タッチしている && 離した瞬間かを返す
	/// </summary>
	/// <returns>結果</returns>
	public bool CheckTouchEnded()
	{
		return this.isTouch && this.touchMode == TouchPhase.Ended;
	}
}
