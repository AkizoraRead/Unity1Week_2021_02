﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// 結果表示操作
/// </summary>
public class ResultController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 結果表示オブジェクト
	/// </summary>
	[SerializeField] GameObject resultObj = null;
	/// <summary>
	/// ステージ名表示のテキスト
	/// </summary>
	[SerializeField] Text stageNameText = null;
	/// <summary>
	/// スコアタイム表示のテキスト
	/// </summary>
	[SerializeField] Text scoreTimeText = null;
	/// <summary>
	/// ボタンテーブル
	/// </summary>
	[SerializeField] GameObject buttonsObj = null;
	//-------------------------------------------------------------------------------
	private void Start()
	{
		//UI 無効化
		//Window表示
		this.resultObj.SetActive(false);

		//ステージ名表示
		this.stageNameText.enabled = false;

		//スコアタイム表示
		this.scoreTimeText.enabled = false;

		//ボタン表示
		this.buttonsObj.SetActive(false);

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 結果表示処理開始
	/// </summary>
	public void ResultStart()
	{
		StartCoroutine(ResultProcess());
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 結果表示処理
	/// </summary>
	/// <returns></returns>
	IEnumerator ResultProcess()
	{
		//UI
		//Window表示
		this.resultObj.SetActive(true);

		//0.5秒待つ
		yield return new WaitForSeconds(1.0f);

		//ステージ名表示
		this.stageNameText.enabled = true;

		//0.5秒待つ
		yield return new WaitForSeconds(1.0f);

		//スコアタイム表示
		this.scoreTimeText.enabled = true;

		//0.5秒待つ
		yield return new WaitForSeconds(1.0f);

		//ボタン表示
		this.buttonsObj.SetActive(true);

		yield break;
	}
	//-------------------------------------------------------------------------------
}
