﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 経過時間表示
/// </summary>
public class TimerTextController : MonoBehaviour
{
    /// <summary>
    /// 使用するテキスト
    /// </summary>
    [SerializeField] Text text  = null;

    // Update is called once per frame
    void Update()
    {
        //更新

        string msg = "経過時間：" + Timer.Instance.DeltaTime.ToString("F1") + "秒";

        this.text.text = msg;
    }
}
