﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// InGame統括 柄子
/// </summary>
public class InGameManager : SingletonClass<InGameManager>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// ステージ番号
    /// </summary>
    public static int stageNum;
    /// <summary>
    /// マップチップ座標X
    /// </summary>
    float[] mapPosX;
    /// <summary>
    /// マップチップ座標Y
    /// </summary>
    float[] mapPosY;
    /// <summary>
    /// ゲーム中か
    /// </summary>
    bool isGaming;

    /// <summary>
    /// カウントダウン処理をするクラス
    /// </summary>
    [SerializeField] GameCountDown countDownClass = null;
    /// <summary>
    /// 結果表示処理をするクラス
    /// </summary>
    [SerializeField] ResultController resultClass = null;
    //-------------------------------------------------------------------------------
    //プロパティ
    /// <summary>
    /// マップチップ座標X
    /// </summary>
    public float[] MapPosX
	{
        get { return this.mapPosX; }
        private set { this.mapPosX = value; }
	}
    /// <summary>
    /// マップチップ座標Y
    /// </summary>
    public float[] MapPosY
    {
        get { return this.mapPosY; }
        private set { this.mapPosY = value; }
    }
    /// <summary>
    /// ゲーム中か
    /// </summary>
    public bool IsGaming
	{
		get { return this.isGaming; }
        private set { this.isGaming = value; }
	}

    //-------------------------------------------------------------------------------
    override protected void AwakeInitialize()
    {
        this.isGaming = false;

        //マップ生成
        MapGenerate();

    }

	//-------------------------------------------------------------------------------
	private void Start()
	{
        //BGM再生


        //カウントスタート
        this.countDownClass.CountDownStart();
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// ゲームスタート
    /// </summary>
    public void GameStart()
	{
        //ゲームモード有効化
        this.isGaming = true;
        Timer.Instance.isCount = true;
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// ゲーム終了
    /// </summary>
    public void GameEnd()
	{
        //ゲームモード無効化
        this.isGaming = false;
        Timer.Instance.isCount = false;

        //結果表示
        this.resultClass.ResultStart();
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// マップ生成
    /// </summary>
    void MapGenerate()
	{
        //データ読み込み(マップ番号名)
        List<string> fileData = FileLoad.DataLoadResource("map" + stageNum.ToString());

        //バグチェック
        if (fileData == null) { Debug.LogError("マップ生成に失敗しました。"); return; }

        //マップデータに変換
        MapLoad mapLoadClass = new MapLoad();
        int[,] mapData = mapLoadClass.ConvertMapData(fileData);


        //Y軸のマス座標を指定
        this.mapPosY = new float[mapData.GetLength(0)];

        //基点となる左端のマスの座標指定
        float point = 0.0f;
        if(mapData.GetLength(1) % 2 == 0)
		{
            point = mapData.GetLength(1) / 2 - 0.5f;
        }
        else
		{
            point = (mapData.GetLength(1) - 1) / 2;
        }

        for(int i = 0; i < mapData.GetLength(1); i++)
		{
            this.mapPosY[i] = point - (i * 1);
		}

        //X軸のマス座標を指定
        this.mapPosX = new float[mapData.GetLength(1)];

        //基点となる上端のマスの座標指定
        if (mapData.GetLength(0) % 2 == 0)
		{
            point = mapData.GetLength(0) / 2 - 0.5f;
        }
        else
		{
            point = (mapData.GetLength(0) - 1) / 2;
        }
        for (int i = 0; i < mapData.GetLength(0); i++)
        {
            this.mapPosX[i] = point - (i * 1);
        }

        //生成
        MapGenerator.Instance.Generate(mapData);
	}
    //-------------------------------------------------------------------------------

}
