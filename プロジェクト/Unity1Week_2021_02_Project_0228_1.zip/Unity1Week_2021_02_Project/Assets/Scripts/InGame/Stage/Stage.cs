﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage : MonoBehaviour
{
    /// <summary>回転スピード</summary>
    float m_RotateSpeed = -10.0f;
    /// <summary>回転量</summary>
    Vector3 m_StageRotate = new Vector3(0.0f, 0.0f, 0.0f);

    void Update()
    {
        // マウスの左クリックが押されている場合
        if (Input.GetMouseButton(0) && InGameManager.Instance.IsGaming)
        {
            // ステージの回転を行う
            MouseRotate();
        }
    }

    /// <summary>ステージの回転</summary>
    void MouseRotate()
    {
        // マウスの入力値
        m_StageRotate.z += Input.GetAxis("Mouse X") * m_RotateSpeed * Time.deltaTime;

        // 入力制限
        if (m_StageRotate.z >= 0.5f) m_StageRotate.z = 0.5f;
        if (m_StageRotate.z <= -0.5f) m_StageRotate.z = -0.5f;

        // 回転
        transform.Rotate(m_StageRotate);
    }
}
