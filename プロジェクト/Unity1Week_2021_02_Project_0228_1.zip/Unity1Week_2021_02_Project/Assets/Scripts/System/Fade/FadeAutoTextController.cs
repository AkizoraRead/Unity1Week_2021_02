﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//------------------------------------------------------
/// <summary>
/// UI 自動でテキストをフェード
/// </summary>
public class FadeAutoTextController : MonoBehaviour
{
	//フィールド
	/// <summary>
	/// 反映するテキスト
	/// </summary>

	[SerializeField] Text	fadeText = null;
	/// <summary>
	/// フェード機能
	/// </summary>
	Fade					fadeClass;
	/// <summary>
	/// フェード間隔
	/// </summary>
	[SerializeField] float	fadeTime = 1.0f;
	//------------------------------------------------------
	void Start()
	{
		this.fadeClass = new Fade(this.fadeText.color);
	}

	void Update()
	{
		//Fade
		this.fadeClass.FadeInOut(this.fadeTime);
		//反映
		this.fadeText.color = this.fadeClass.GetColor();
	}
	//------------------------------------------------------
}
