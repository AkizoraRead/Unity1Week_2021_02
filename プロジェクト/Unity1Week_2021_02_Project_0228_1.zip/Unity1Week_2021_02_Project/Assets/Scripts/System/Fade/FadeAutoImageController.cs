﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//------------------------------------------------------
/// <summary>
/// UI 自動でImageをフェード
/// </summary>
public class FadeAutoImageController : MonoBehaviour
{
	//フィールド
	/// <summary>
	/// 反映するテキスト
	/// </summary>

	[SerializeField] Image   fadeImage = null;
	/// <summary>
	/// フェード機能
	/// </summary>
	Fade                    fadeClass;
	/// <summary>
	/// フェード間隔
	/// </summary>
	[SerializeField] float  fadeTime = 1.0f;
	//------------------------------------------------------
	void Start()
	{
		this.fadeClass = new Fade(this.fadeImage.color);
	}

	void Update()
	{
		//Fade
		this.fadeClass.FadeInOut(this.fadeTime);
		//反映
		this.fadeImage.color = this.fadeClass.GetColor();
	}
	//------------------------------------------------------
}
