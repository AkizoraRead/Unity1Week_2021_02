﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//-------------------------------------------------------------------------------
/// <summary>
/// ボタンで使用するアクション
/// </summary>
public class ButtonAction : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// シーン変移
	/// </summary>
	/// <param name="sceneName">次のシーン名</param>
	public void SceneChange(string sceneName)
	{
		SceneChangeManager.Instance.SceneChange(sceneName);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ステージ選択、決定の確認ウィンドウの表示
	/// </summary>
	/// <param name="stageNum_">ステージ番号</param>
	public void SelectStage(int stageNum_)
	{
		//ステージ番号代入
		InGameManager.stageNum = stageNum_;
		//ウィンドウ表示
		ConfirmationObjController.Instance.Active
			(
				(() => SceneChangeManager.Instance.SceneChange("InGameScene")),	//シーン変移
				null,
				"ステージ" + stageNum_
			);

		
	}
	//-------------------------------------------------------------------------------
}
