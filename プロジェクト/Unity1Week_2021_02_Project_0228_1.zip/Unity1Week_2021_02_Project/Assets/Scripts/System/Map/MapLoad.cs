﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// テキストデータを読み込んでマップデータにする
/// </summary>
public class MapLoad
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// マップデータに変換
	/// </summary>
	/// <param name="datas">元データ（文字列）</param>
	/// <returns></returns>
	public int[,] ConvertMapData(List<string> datas)
	{
		int width	= int.Parse(datas[0].Split(',')[0]);	//1行目 1項目
		int height	= int.Parse(datas[0].Split(',')[1]);    //1行目 2項目

		//データ格納
		int[,] mapDatas = new int[height,width];

		//行
		for(int i = 1; i <= height; i++)
		{
			//列
			for(int j = 0; j < width; j++)
			{
				//バグチェック
				if(datas[i].Split(',')[j] == null) 
				{ Debug.LogWarning("データがありませんでした。：" + this.ToString() + " " + i + "行目 " + j + "番目"); continue; }

				mapDatas[i - 1, j] = int.Parse(datas[i].Split(',')[j]);
			}
		}

		return mapDatas;
	}
	//-------------------------------------------------------------------------------
}
