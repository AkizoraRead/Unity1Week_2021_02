﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>マップの生成のクラス</summary>
public class MapGenerator : SingletonClass<MapGenerator>
{
    [SerializeField, Header("ステージの中心位置")]
    private GameObject m_StageCenter;
    [SerializeField, Header("壁")]
    private GameObject m_Wall;
    [SerializeField, Header("道")]
    private GameObject m_Road;
    [SerializeField, Header("穴")]
    private GameObject m_Hole;
    [SerializeField, Header("プレイヤーの出現位置")]
    private GameObject m_PlayerPop;
    [SerializeField, Header("ゴール")]
    private GameObject m_Goal;


    /// <summary>マップの生成</summary>
    public void Generate(int[,] Mapdata) 
    {

        for(int  height = 0; height < Mapdata.GetLength(0); height++)
        {
            for(int width = 0; width < Mapdata.GetLength(1); width++)
            {
                switch(Mapdata[height, width])
                {
                    case 0: Wall(height, width); break;
                    case 1: Road(height, width); break;
                    case 2: Hole(height, width); break;
                    case 3: PlayerPop(height, width); break;
                    case 4: Goal(height, width); break;
                }
            }
        }
    }

    /// <summary>壁</summary>
    void Wall(int height, int width)
    {
        GameObject Wall;
        Wall = Instantiate(m_Wall, m_StageCenter.transform);
        Wall.transform.position = MapPos(height, width);
    }

    /// <summary>道</summary>
    void Road(int height, int width)
    {
        GameObject Road;
        Road = Instantiate(m_Road, m_StageCenter.transform);
        Road.transform.position = MapPos(height, width);
    }

    /// <summary>穴</summary>
    void Hole(int height, int width)
    {
        GameObject Hole;
        Hole = Instantiate(m_Hole, m_StageCenter.transform);
        Hole.transform.position = MapPos(height, width);
    }

    /// <summary>プレイヤーのリスポーン地点</summary>
    void PlayerPop(int height, int width)
    {
        GameObject PlayerPop;
        PlayerPop = Instantiate(m_PlayerPop, m_StageCenter.transform);
        PlayerPop.transform.position = MapPos(height, width);
    }

    /// <summary>ゴール</summary>
    void Goal(int height, int width)
    {
        GameObject Goal;
        Goal = Instantiate(m_Goal, m_StageCenter.transform);
        Goal.transform.position = MapPos(height, width);
    }

    Vector2 MapPos(int height, int width) {
        return new Vector2(InGameManager.Instance.MapPosX[width], InGameManager.Instance.MapPosY[height]);
    }
}
